import{t as e}from"./chunk-1VNLd2iN.js";var t=e((()=>{var e=`https://api.deepseek.com/chat/completions`,t=`deepseek-v4-flash`,n=`enabled`,r=`high`;chrome.runtime.onInstalled.addListener(async()=>{try{await chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:!0})}catch(e){console.warn(`[dga] sidePanel.setPanelBehavior failed`,e)}}),chrome.action.onClicked.addListener(async e=>{try{e&&typeof e.windowId==`number`&&await chrome.sidePanel.open({windowId:e.windowId})}catch(e){console.warn(`[dga] sidePanel.open failed`,e)}});async function i(){let{deepseekApiKey:e,anthropicApiKey:t}=await chrome.storage.local.get([`deepseekApiKey`,`anthropicApiKey`]);return e||t||``}async function a(){let{model:e}=await chrome.storage.local.get(`model`);return e||t}async function o(){let{thinkingMode:e,reasoningEffort:t}=await chrome.storage.local.get([`thinkingMode`,`reasoningEffort`]);return{mode:e||n,effort:t||r}}function s(e){return!e||!e.pageMarkdown?``:`\n\nPAGE AS MARKDOWN (live page rendered via Turndown — headings, links, lists, prose; use ONLY as background reading to disambiguate the interactive elements above. Selectors MUST still come from the distilled list, not from this Markdown):\n${e.pageMarkdown}`}function c(e){let t=e&&e.focusedRef;return{elementsCompact:(e.elements||[]).map(e=>{let n=[];n.push(`<${e.tag}>`),e.testid&&n.push(`testid="${e.testid}"`),e.id&&n.push(`id="${e.id}"`),e.ariaLabel&&n.push(`aria-label="${e.ariaLabel}"`),e.placeholder&&n.push(`placeholder_hint=${JSON.stringify(e.placeholder)}`),e.name&&n.push(`name="${e.name}"`),e.role&&n.push(`role="${e.role}"`),e.type&&n.push(`type="${e.type}"`),e.href&&n.push(`href="${e.href}"`),e.text&&n.push(`text=${JSON.stringify(e.text)}`),typeof e.value==`string`&&e.value.length?n.push(`current_value=${JSON.stringify(e.value)} FILLED`):e.empty===!0&&n.push(`EMPTY`),e.checked===!0&&n.push(`checked`),e.checked===!1&&n.push(`unchecked`),e.disabled&&n.push(`disabled`),(e.focused||e.ref===t)&&n.push(`FOCUSED`),e.position&&n.push(`position=${e.position}`),e.inViewport||n.push(`off-screen`);let r=e.nearLabel?`\n      near: ${JSON.stringify(e.nearLabel)}`:``;return`  ${e.ref}: ${n.join(` `)}${r}\n      selector: ${e.selector}`}).join(`
`),headings:(e.headings||[]).map(e=>`  ${e.tag}: ${e.text}`).join(`
`)}}function l(e){return!Array.isArray(e)||e.length===0?``:`\n\nLEARNED RULES FROM USER CHAT (the user corrected the agent in chat — these are durable rules distilled from that conversation; FOLLOW them on this step):\n${e.map((e,t)=>`  ${t+1}. ${e}`).join(`
`)}`}function u({dom:e,url:t,title:n}){let{elementsCompact:r,headings:i}=c(e);return`CURRENT PAGE (THE GROUND TRUTH):
URL: ${t}
Title: ${n}
${e&&e.focusedRef?`Focused element: ${e.focusedRef} (tag <${e.activeElementTag||`?`}>) — the user has clicked into this field.`:`Focused element: (none — no input has focus)`}

Section headings:
${i||`  (none)`}

Interactive elements on the page (with stable CSS selectors; each line shows position + nearby label + live state like FOCUSED / current_value / checked):
${r||`  (none found)`}${s(e)}`}function d(e){return e&&e.length?e.map((e,t)=>`  ✓ ${t+1}. DONE — ${e}`).join(`
`):`  (none yet — this is step 1)`}function f(e){return e&&e.length?e.map((e,t)=>{let n=e.completedAt?` (completed ${e.completedAt})`:``;return`  ✓ ${t+1}. on ${e.url}${n}\n      DONE — clicked selector: ${e.selector}\n      what they did: "${e.narration}"`}).join(`
`):`  (none yet — this is the first action)`}var p=`{
  "currentState": "<one sentence: where the user is right now, from the live page>",
  "progressAssessment": "<one sentence: what's done vs what's left>",
  "selector": "<CSS selector verbatim from the list above, or null>",
  "narration": "<one short imperative sentence>",
  "confidence": 0.0,
  "reasoning": "<one sentence on why this click is correct>",
  "alternatives": [],
  "blocker": null,
  "done": false
}`,m=`Hard rules:
- "selector" MUST be copied verbatim from a "selector:" line above, or null. Never invent a selector.
- If the right element isn't on the live page, set selector=null and explain in "blocker". Don't guess.
- "narration" is what the user reads — short, imperative.
- "confidence" 0.0-1.0. Be honest.
- "alternatives": when the user step is phrased as "click ONE OF the X / ANY of the X / pick a X" and multiple elements equally satisfy it (e.g. several objectives in a list, several rows in a table, several cards in a grid), list the OTHER equivalent selectors here (excluding the one in "selector"). Verbatim from the list. Up to 8 entries. When only one element fits, return an empty array. Phrase the narration so the user knows they have a choice (e.g. "Click any of the highlighted objectives — they all work").
- **Form-field state — read EMPTY and FILLED literally.** Each editable input is tagged with one of two flags in the element list:
    • \`FILLED\` plus its \`current_value=...\` — the user has typed something. Treat as done for that field.
    • \`EMPTY\` — the field has NO actual user content. The next action for this field is to TYPE INTO IT.
  \`placeholder_hint="..."\` is **NOT a value**. It is the greyed-out hint text the browser shows in an empty field. An EMPTY field with a placeholder is still EMPTY.
  \`FOCUSED\` is **NOT a value either**. A field can be EMPTY + FOCUSED at the same time (the user clicked into it but hasn't typed yet) — that means "the user is about to type", not "done".
- **Forms specifically:** never suggest clicking a submit button (Sign In, Login, Save, Continue, Submit, Next, Add, Create) while ANY visible input is marked EMPTY. The submit will fail validation. Pick the next EMPTY input and tell the user to fill it. Word the narration like "Type your password" or "Fill in the weight field" — point at the input, not the submit.`;function h({goal:e,history:t,dom:n,url:r,title:i,iter:a,maxIter:o,learnedRules:s}){return`You are one of two parallel reasoners. Your job: find the next click PURELY from the live page. You have NO documentation, NO author hints, NO knowledge base. Reason only from the DOM and visible labels — except for any LEARNED RULES below, which the user corrected the agent on and you should respect.

GOAL:
${e}${l(s)}

✓ COMPLETED ACTIONS (the user has already done these — DO NOT re-suggest):
${f(t)}

${u({dom:n,url:r,title:i})}

This is iteration ${a+1} of at most ${o}.

Think in two steps:
A — Where am I now? (live page only)
B — Given the goal + completed actions + current state, what is the SINGLE next click that moves forward?

Return ONLY raw JSON in this exact shape:
${p}

${m}
- Set "done": true only when the GOAL is achieved (current page proves it). When done, selector may be null and narration should congratulate the user.
- Do NOT pick a selector that already appears in ✓ COMPLETED ACTIONS unless the live page state proves the prior click had no effect.`}function g({goal:e,hints:t,knowledge:n,history:r,dom:i,url:a,title:o,iter:s,maxIter:c,learnedRules:d}){return`You are one of two parallel reasoners. Your job: follow the author's documentation as closely as possible, mapping the prescribed next step onto the live page.

GOAL:
${e}

AUTHOR HINTS (your primary guide for this goal):
${t||`(none)`}

KNOWLEDGE BASE (other authored flows — vocabulary + behaviour reference):
${n||`(empty)`}${l(d)}

✓ COMPLETED ACTIONS (the user has already done these — pick the NEXT one in the documented sequence):
${f(r)}

${u({dom:i,url:a,title:o})}

This is iteration ${s+1} of at most ${c}.

Think in two steps:
A — What do the hints / knowledge say should happen next (given completed actions)?
B — Which element on the LIVE PAGE matches that prescribed step? If nothing matches, return selector=null and explain in blocker.

Return ONLY raw JSON in this exact shape:
${p}

${m}
- Set "done": true only when the GOAL is achieved.
- Do NOT pick a selector that already appears in ✓ COMPLETED ACTIONS.
- If hints/knowledge prescribe an element that simply isn't present, set selector=null and explain — don't substitute.`}function _({allSteps:e,flowTitle:t,flowGoal:n,dom:r,url:i,title:a,learnedRules:o}){let s=e.map((e,t)=>`  ${t+1}. ${e}`).join(`
`);return`You are the STATE ASSESSOR for a multi-step walkthrough. Your job: look at the LIVE PAGE and the list of steps, then decide where the user currently is.

WALKTHROUGH:
title: ${t||`(untitled)`}
goal: ${n||`(no goal stated)`}

ALL STEPS (in order):
${s}${l(o)}

${u({dom:r,url:i,title:a})}

Think:
A — What does the live page show? (URL, headings, key elements)
B — Which steps from ALL STEPS look like they've already been done? (e.g. if the user is on the "new issue" form, steps that say "click Issues tab" and "click New issue button" are obviously done)
C — Which step is the user about to do RIGHT NOW (the next un-done one)?

Return ONLY raw JSON:
{
  "currentState": "<one sentence describing the live page>",
  "currentStepIndex": <0-based index — which step the user should do next>,
  "doneStepIndices": [<0-based indices of steps that already look completed>],
  "reasoning": "<one sentence — why this is the right step pointer>"
}

Rules:
- Indices are 0-based (step 1 = index 0).
- doneStepIndices must be a strict prefix of currentStepIndex when steps are sequential, EXCEPT if the user skipped ahead.
- If completely unsure, set currentStepIndex to the smallest un-done index and explain why in reasoning.`}function v({stepText:e,stepIndex:t,totalSteps:n,allSteps:r,dom:i,url:a,title:o,learnedRules:s}){let c=r.map((e,n)=>n===t?`  ${n+1}. **MY STEP**: ${e}`:`  ${n+1}. ${e}`).join(`
`);return`You are the per-step reasoner for ONE specific step in a multi-step walkthrough. Other reasoners cover the other steps in parallel; an orchestrator will merge our outputs.

YOUR ASSIGNED STEP (step ${t+1} of ${n}):
  ${e||`(empty)`}

Full walkthrough (yours marked **MY STEP**):
${c}${l(s)}

${u({dom:i,url:a,title:o})}

Decide:
A — Does the LIVE PAGE right now match YOUR step? (Is the page in the state where this step would happen?)
B — If yes, point at the element to click. If no, set selector=null and lower confidence.

Return ONLY raw JSON:
{
  "applicableNow": <true if the live page is currently in the right state for MY step, false otherwise>,
  "currentState": "<one sentence: how the page relates to MY step>",
  "selector": "<verbatim from the list, or null>",
  "narration": "<one short imperative sentence for MY step>",
  "confidence": 0.0,
  "reasoning": "<one sentence on why this element matches MY step OR why MY step isn't applicable right now>",
  "blocker": null
}

Rules:
- "selector" verbatim from the "selector:" lines above, or null. Never invent.
- "applicableNow": true ONLY if the page is in the right state for YOUR specific step. If the page is past or before your step, set false.
- "confidence": be honest. 0.8+ only when the page clearly matches your step AND a specific element fits. <0.3 if your step is clearly not applicable.`}async function y({apiKey:t,model:n,system:r,user:i,jsonMode:a=!0}){let s={model:n,temperature:0,messages:[{role:`system`,content:r},{role:`user`,content:i}]};a&&(s.response_format={type:`json_object`});let c=await o();c.mode===`enabled`?s.thinking={type:`enabled`,reasoning_effort:c.effort}:c.mode===`disabled`&&(s.thinking={type:`disabled`});let l=await fetch(e,{method:`POST`,headers:{"content-type":`application/json`,authorization:`Bearer ${t}`},body:JSON.stringify(s)});if(!l.ok){let e=await l.text().catch(()=>``);throw Error(`DeepSeek ${l.status}: ${e.slice(0,400)}`)}let u=await l.json();return(u.choices&&u.choices[0]&&u.choices[0].message&&u.choices[0].message.content||``).trim()}function b(e){let t=e.trim(),n=t.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/i);if(n&&(t=n[1].trim()),!t.startsWith(`{`)){let e=t.match(/\{[\s\S]*\}/);e&&(t=e[0])}return JSON.parse(t)}var x=`You output ONLY raw JSON conforming to the schema the user describes. Never wrap responses in markdown fences. Never include prose before or after the JSON.`;function S(e){let t=e||{};return{currentState:t.currentState||``,progressAssessment:t.progressAssessment||``,selector:typeof t.selector==`string`?t.selector:null,narration:t.narration||``,confidence:typeof t.confidence==`number`?t.confidence:0,reasoning:t.reasoning||``,blocker:t.blocker||null,done:t.done===!0,applicableNow:t.applicableNow===!0,alternatives:Array.isArray(t.alternatives)?t.alternatives.filter(e=>typeof e==`string`):[]}}async function C({apiKey:e,model:t,prompt:n}){let r=``;try{r=await y({apiKey:e,model:t,system:x,user:n,jsonMode:!0});let i=b(r);return{currentState:i.currentState||``,currentStepIndex:typeof i.currentStepIndex==`number`?i.currentStepIndex:null,doneStepIndices:Array.isArray(i.doneStepIndices)?i.doneStepIndices.filter(e=>typeof e==`number`):[],reasoning:i.reasoning||``,raw:r}}catch(e){return{currentState:``,currentStepIndex:null,doneStepIndices:[],reasoning:``,raw:r,error:String(e&&e.message||e)}}}async function w({apiKey:e,model:t,prompt:n}){let r=``;try{return r=await y({apiKey:e,model:t,system:x,user:n,jsonMode:!0}),{...S(b(r)),raw:r}}catch(e){return{...S({}),raw:r,error:String(e&&e.message||e)}}}function T(e,t){let n,r,i,a,o,s,c=e.done||t.done;!e.selector&&!t.selector?(n=`neither`,r=null,i=e.narration||t.narration||``,a=0,o=`Neither reasoner found a matching element on the live page.`,s=e.blocker||t.blocker||`No matching element on this page.`):e.selector&&t.selector&&e.selector===t.selector?(n=`agreed`,r=e.selector,i=t.narration||e.narration,a=Math.min(1,Math.max(e.confidence,t.confidence)+.1),o=`Both reasoners agreed. Page: ${e.reasoning} Docs: ${t.reasoning}`,s=null):e.selector?t.selector?(e.confidence>t.confidence+.001?(n=`page`,r=e.selector,i=e.narration,a=e.confidence*.85,o=`Disagree — chose page (conf ${e.confidence.toFixed(2)} vs docs ${t.confidence.toFixed(2)}). Page: ${e.reasoning}`):t.confidence>e.confidence+.001?(n=`docs`,r=t.selector,i=t.narration,a=t.confidence*.85,o=`Disagree — chose docs (conf ${t.confidence.toFixed(2)} vs page ${e.confidence.toFixed(2)}). Docs: ${t.reasoning}`):(n=`page`,r=e.selector,i=e.narration,a=e.confidence*.8,o=`Tie — defaulted to page (live-grounded). Page: ${e.reasoning}`),s=null):(n=`page`,r=e.selector,i=e.narration,a=e.confidence,o=`Docs reasoner had no candidate; page picked: ${e.reasoning}`,s=e.blocker):(n=`docs`,r=t.selector,i=t.narration,a=t.confidence,o=`Page reasoner had no candidate; docs picked: ${t.reasoning}`,s=t.blocker);let l=n===`docs`||n===`agreed`?t:e,u=Array.isArray(l.alternatives)?l.alternatives:[];return{currentState:e.currentState||t.currentState,progressAssessment:e.progressAssessment||t.progressAssessment,candidateFromPage:{...e,raw:void 0},candidateFromDocs:{...t,raw:void 0},chosen:n,selector:r,narration:i,confidence:a,reasoning:o,blocker:s,alternatives:u,done:c}}async function E(e){let t=await i();if(!t)throw Error(`No DeepSeek API key set. Open the extension options to paste your key.`);let n=await a(),r=typeof e.stepIndex==`number`?e.stepIndex:0,o=[...e.completedSteps||[],e.stepText||``,...e.remainingSteps||[]],s={dom:e.dom,url:e.url,title:e.title},c=Array.isArray(e.learnedRules)?e.learnedRules:[],l=C({apiKey:t,model:n,prompt:_({allSteps:o,flowTitle:e.flowTitle,flowGoal:e.flowGoal,learnedRules:c,...s})}),u=o.map((e,r)=>w({apiKey:t,model:n,prompt:v({stepText:e,stepIndex:r,totalSteps:o.length,allSteps:o,learnedRules:c,...s})})),d=w({apiKey:t,model:n,prompt:D({goal:e.flowGoal||e.flowTitle,completedSteps:e.completedSteps,learnedRules:c,...s})}),[f,p,...m]=await Promise.all([l,d,...u]),h=f.currentStepIndex!=null&&f.currentStepIndex>=0&&f.currentStepIndex<o.length?f.currentStepIndex:r,g=m[h]||m[r]||S({}),y,b,x,T,E,O,k=.001;!g.selector&&!p.selector?(y=`neither`,b=null,x=g.narration||p.narration||``,T=0,E=`Neither step-following nor free-form agent found a matching element.`,O=g.blocker||p.blocker||`No matching element on this page.`):g.selector&&p.selector&&g.selector===p.selector?(y=`agreed`,b=g.selector,x=g.narration||p.narration,T=Math.min(1,Math.max(g.confidence,p.confidence)+.1),E=`Step-following and free-form agreed. Step: ${g.reasoning} Free-form: ${p.reasoning}`,O=null):g.selector?p.selector?p.confidence>g.confidence+k?(y=`invented`,b=p.selector,x=p.narration,T=p.confidence*.85,E=`Free-form agent invented a higher-confidence pick (${p.confidence.toFixed(2)} vs step ${g.confidence.toFixed(2)}). Reason: ${p.reasoning}`,O=null):g.confidence>p.confidence+k?(y=`step`,b=g.selector,x=g.narration,T=g.confidence,E=`Step-following won (${g.confidence.toFixed(2)} vs free-form ${p.confidence.toFixed(2)}). Reason: ${g.reasoning}`,O=null):(y=`step`,b=g.selector,x=g.narration,T=g.confidence*.9,E=`Tied — defaulted to step-following. Reason: ${g.reasoning}`,O=null):(y=`step`,b=g.selector,x=g.narration,T=g.confidence,E=`Free-form had no candidate; following the step: ${g.reasoning}`,O=g.blocker):(y=`invented`,b=p.selector,x=p.narration,T=p.confidence,E=`Step-following had no element; free-form invented: ${p.reasoning}`,O=p.blocker);let A=m.map((e,t)=>({stepIndex:t,stepText:o[t],applicableNow:e.applicableNow,selector:e.selector,narration:e.narration,confidence:e.confidence,reasoning:e.reasoning})),j=y===`invented`?p:y===`step`||y===`agreed`?g:null,M=j&&Array.isArray(j.alternatives)?j.alternatives.filter(e=>e!==b):[];return{currentState:f.currentState||g.currentState||p.currentState||``,progressAssessment:`Assessor suggests step ${h+1} of ${o.length}. Done so far: [${(f.doneStepIndices||[]).map(e=>e+1).join(`, `)||`none`}].`,suggestedStepIndex:h,doneStepIndices:f.doneStepIndices||[],perStepCandidates:A,freeFormCandidate:{selector:p.selector,narration:p.narration,confidence:p.confidence,reasoning:p.reasoning},chosenSource:y,selector:b,narration:x,confidence:T,reasoning:E,alternatives:M,blocker:O,rawState:f.raw,rawCandidates:m.map(e=>e.raw),rawFreeForm:p.raw}}function D({goal:e,completedSteps:t,dom:n,url:r,title:i,learnedRules:a}){return`You are the FREE-FORM page reasoner. You DO NOT see the scripted step text. Your job: look at the live page + goal + what's been completed, and pick the SINGLE most natural next click — invent it from the page itself. Respect any LEARNED RULES below (those are corrections the user gave the agent in chat).

GOAL:
${e||`(no goal stated)`}${l(a)}

✓ COMPLETED STEPS (already done — do not re-pick these):
${d(t)}

${u({dom:n,url:r,title:i})}

Think:
A — What screen / state is the live page in?
B — Given the goal and what's already been done, what is the single best next click? Reason from the page alone — labels, headings, what visibly stands out.

Return ONLY raw JSON:
{
  "currentState": "<one sentence: what the live page is>",
  "selector": "<verbatim from the list, or null>",
  "narration": "<one short imperative sentence>",
  "confidence": 0.0,
  "reasoning": "<one sentence: why this click is the best next move based purely on the live page>",
  "blocker": null
}

Rules:
- selector verbatim from the list. Never invent.
- If the page doesn't suggest a clear next click, set selector=null with a blocker.
- confidence reflects how natural the pick feels given the goal + page.`}async function O(e){let t=await i();if(!t)throw Error(`No DeepSeek API key set. Open the extension options to paste your key.`);let n=await a(),r={...e,learnedRules:Array.isArray(e.learnedRules)?e.learnedRules:[]},o=h(r),s=g(r),[c,l]=await Promise.all([w({apiKey:t,model:n,prompt:o}),w({apiKey:t,model:n,prompt:s})]);return{...T(c,l),rawPage:c.raw,rawDocs:l.raw}}function k({question:e,history:t,goal:n,flowMode:r,currentStep:i,knowledge:a,dom:o,url:l,title:u}){let{elementsCompact:d,headings:f}=o?c(o):{elementsCompact:``,headings:``},p=t&&t.length?t.map(e=>`  ${e.role===`user`?`USER`:`AGENT`}: ${e.text}`).join(`
`):`  (no prior turns)`;return`You are the CORRECTION ASSESSOR for an in-browser guide. The user clicked "Correct Agent If Wrong" because the agent picked the wrong thing. Your ONLY job is to LISTEN to their correction, analyze it against the live page, and decide whether you've understood and the user has agreed — OR whether you need to keep talking.

You do NOT tell the user what to do on the page. You do NOT guide them. You're a listener confirming understanding so the corrected rule can be saved.

GOAL: ${n||`(none)`}
CURRENT STEP / ITERATION: ${i||`(none)`}
flow mode: ${r||`(unknown)`}

LIVE PAGE:
URL: ${l||`(unknown)`}
Title: ${u||`(unknown)`}

Section headings:
${f||`  (none)`}

Interactive elements:
${d||`  (none captured)`}${s(o)}

KNOWLEDGE BASE (other authored flows for vocabulary):
${a||`(empty)`}

CHAT HISTORY (oldest first):
${p}

USER'S NEW MESSAGE:
${e||`(empty)`}

Think:
A — What is the user correcting? Which element / behaviour are they pointing at?
B — Can you ground that in the LIVE PAGE? Which element matches what they described?
C — Is their intent clear, and have they explicitly confirmed your understanding?

Return ONLY raw JSON in this exact shape:
{
  "content": "<your reply to the user — short, conversational, 1-2 sentences. Either summarise your understanding and ASK them to confirm (e.g. \\"Got it, you mean the green Save button on the right — is that right?\\"), OR ask a clarifying question if their meaning is still unclear.>",
  "decision": "agreed" | "pending" | "disagreed",
  "reasoning": "<one sentence on why this decision>"
}

Decision rules:
- "agreed" — set ONLY when the user has explicitly confirmed your reading. Acceptance words: "yes", "correct", "exactly", "right", "that's it", "ok", "👍". On the user's FIRST correction message, do NOT preemptively mark agreed even if their direction is clear — summarise and ASK first; agreed comes on the next turn when they say yes.
- "disagreed" — the user contradicts the live page OR explicitly says you've still got it wrong and wants to bail.
- "pending" — default. Conversation is developing, more clarification needed, or you just asked a confirm-question and the user hasn't yet replied.

Style:
- "content" is conversational, NOT instructional. No "click X" / "do Y" — only confirming or clarifying.
- Keep it short. Don't dump page state at them.
- "content" never contains JSON / markdown fences — it's plain prose inside the JSON string.`}function A({goal:e,chatHistory:t,existingRules:n,dom:r,url:i,title:a,currentStep:o}){let s=(t||[]).slice(-6).map(e=>`  ${e.role===`user`?`USER`:`AGENT`}: ${e.text}`).join(`
`),c=(n||[]).map((e,t)=>`  ${t+1}. ${e}`).join(`
`),l=r?`\n\n${u({dom:r,url:i,title:a})}`:``;return`You are the RULE DISTILLER for an in-browser guide agent. The user just had a chat with the agent. Extract DURABLE corrections / app-specific knowledge from the conversation that the step picker should apply on the NEXT iterations. Use the LIVE PAGE as ground truth — your rules can reference specific elements you see on the current page.

GOAL the user is working on:
${e||`(none — adhoc question)`}

CURRENT STEP / ITERATION:
${o||`(none in progress)`}

EXISTING LEARNED RULES (don't repeat these; add new ones if applicable):
${c||`  (none)`}

RECENT CHAT (most recent at the bottom):
${s||`  (none)`}${l}

Now think:
A — What did the user correct or clarify in the chat?
B — Looking at the LIVE PAGE above, which element(s) does that correction map onto?
C — What durable rule(s) should future iterations follow to act on this knowledge?

Return ONLY raw JSON in this shape:
{
  "rules": [
    "<one short imperative rule the agent should follow next time>",
    "..."
  ]
}

Rules:
- Output 0-3 rules. Empty array if the chat was informational only (no correction, no new app knowledge).
- Rules MUST be specific (page-/app-/element-level), grounded in the live page when possible. Reference labels / placements / behaviour you can see.
- Each rule is one sentence, imperative voice.
- Do NOT repeat existing rules.
- Examples of good rules:
    "The green 'Save' button is in the top right of the form, not the orange 'Submit' in the dialog."
    "Customer dropdown needs typing first before options appear; don't try to click an empty dropdown."
    "After filling the form, click 'Add key result' (not 'Save')."
- Examples of bad rules (do not output):
    "Be careful." / "Follow the user's instructions."`}async function j(e){let t=await i();if(!t)throw Error(`No DeepSeek API key set.`);let n=await y({apiKey:t,model:await a(),system:x,user:A(e),jsonMode:!0}),r;try{r=b(n)}catch{r={}}return(Array.isArray(r.rules)?r.rules.filter(e=>typeof e==`string`&&e.trim()):[]).slice(0,3)}async function M(e){let t=await i();if(!t)throw Error(`No DeepSeek API key set.`);let n=await y({apiKey:t,model:await a(),system:x,user:k(e),jsonMode:!0}),r;try{r=b(n)}catch{r={}}return{content:typeof r.content==`string`&&r.content.trim()||n.trim()||``,decision:[`agreed`,`pending`,`disagreed`].includes(r.decision)?r.decision:`pending`,reasoning:r.reasoning||``}}function N({raw:e,filename:t}){return`You are the FLOW INGESTION agent. Read arbitrary markdown a user dropped into the extension and produce CANONICAL flow markdown the parser can run. Input can be ANY shape: numbered list, bulleted list, paragraphs of prose, a single sentence goal, mixed sections, partial frontmatter, no frontmatter at all, headings out of order, multiple actions mashed into one line, etc. Your job is to extract intent and emit a clean flow.

CANONICAL OUTPUT FORMAT (exact shape the parser expects):

---
id: <kebab-case slug>
title: <human-readable title>
url: <Chrome-style glob — only include if a URL or host can be inferred>
mode: <"scripted" or "agent">
goal: <one sentence describing the end state the user wants to reach>
triggers:
  - <phrase 1>
  - <phrase 2>
---

# Title

## Step 1
<ONE concrete action>

## Step 2
<ONE concrete action>

(When mode is "agent" the ## Step sections are omitted and the body becomes free-form prose used as hints fed to the agent on every iteration.)

INPUT FILENAME: ${t||`(unknown)`}

RAW INPUT:
"""
${e}
"""

Rules — apply to any markdown shape, not just the example above:

1. **One concrete action per step.** If the input bundles multiple actions in one bullet/sentence (any phrasing that mashes verbs together), split them into separate ## Step N entries. A step like "open the menu and click Settings" becomes two steps.

2. **Strip navigation that just gets the user to a URL.** If any step is essentially "go to / navigate to / open <URL>", extract the URL into the \`url:\` frontmatter as a Chrome-style glob. **Always broaden to the host root** — e.g. \`https://app.example.com/login\` becomes \`https://app.example.com/*\`. Never pin the glob to a specific path or subpath unless the input EXPLICITLY restricts the flow to that path. The user routinely starts the same flow from any page on the host (dashboard, settings, deep links). Drop the navigate step from the list — the user is already on the host when they run the flow.

3. **Inline explanatory context.** If the input includes parenthetical definitions, clarifications, or examples for a step (e.g. "(option A means X, option B means Y)"), attach them to the relevant step's prose so the agent has the context. Don't drop nuance.

4. **High-level "fill the form" steps get expanded.** If a step refers vaguely to filling multiple fields or making multiple selections, enumerate each field as its own step.

5. **Mode pick:**
   - \`scripted\` — input is clearly a discrete list of steps the user wants performed in order. Most user-dropped flows.
   - \`agent\` — input is a single high-level goal with no enumerated steps, OR the steps depend heavily on the live page state.

6. **Frontmatter generation:**
   - \`id\`: kebab-case slug **derived from the INPUT FILENAME** (strip extension, lowercase, alphanumerics + dashes only). The filename is what the user picked to identify this specific flow — different files MUST get different ids even if their titles or contents are similar. Only fall back to a title-derived slug if the filename is missing or unhelpful (e.g. \`untitled.md\`).
   - \`title\`: derived from the first H1, or first line, or inferred from the goal. May differ from id.
   - \`url\`: only include when a URL/host can be inferred from the input.
   - \`goal\`: one sentence describing the destination/outcome.
   - \`triggers\`: 2-4 short phrases the user might say to invoke this flow ("create order", "new invoice", etc.). Keep them lowercase, no punctuation.

7. **Preserve user intent.** Don't invent steps the user didn't describe. Don't drop information they did describe. When in doubt, prefer fidelity over brevity.

8. **Output the canonical markdown ONLY.** No JSON wrapping. No code fences around the output. No prose before or after the markdown. The first line of your output must be \`---\`.`}async function P(e){let t=await i();if(!t)throw Error(`No DeepSeek API key set.`);let n=await y({apiKey:t,model:await a(),system:`You output ONLY canonical markdown matching the schema the user describes. No JSON wrapping, no code fences around the markdown, no prose before or after.`,user:N(e||{}),jsonMode:!1});n=n.trim();let r=n.match(/^```(?:markdown|md)?\s*\n?([\s\S]*?)\n?```\s*$/i);return r&&(n=r[1].trim()),n}async function F(){let e=await i();if(!e)throw Error(`No API key set`);return await y({apiKey:e,model:await a(),system:`Respond with the single word OK.`,user:`ping`,jsonMode:!1})}chrome.runtime.onMessage.addListener((e,t,n)=>!e||!e.type?!1:e.type===`TRANSLATE_STEP`?(E(e.payload||{}).then(e=>n({ok:!0,result:e})).catch(e=>n({ok:!1,error:String(e&&e.message||e)})),!0):e.type===`AGENT_STEP`?(O(e.payload||{}).then(e=>n({ok:!0,result:e})).catch(e=>n({ok:!1,error:String(e&&e.message||e)})),!0):e.type===`CHAT`?(M(e.payload||{}).then(e=>n({ok:!0,text:e.content,decision:e.decision,reasoning:e.reasoning})).catch(e=>n({ok:!1,error:String(e&&e.message||e)})),!0):e.type===`DISTILL_RULES`?(j(e.payload||{}).then(e=>n({ok:!0,rules:e})).catch(e=>n({ok:!1,error:String(e&&e.message||e)})),!0):e.type===`INGEST_FLOW`?(P(e.payload||{}).then(e=>n({ok:!0,canonicalMd:e})).catch(e=>n({ok:!1,error:String(e&&e.message||e)})),!0):e.type===`PING_PROVIDER`||e.type===`PING_ANTHROPIC`?(F().then(e=>n({ok:!0,text:e})).catch(e=>n({ok:!1,error:String(e&&e.message||e)})),!0):!1)}));export default t();