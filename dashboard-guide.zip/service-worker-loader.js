import './assets/service-worker.js-DBofit4K.js';
